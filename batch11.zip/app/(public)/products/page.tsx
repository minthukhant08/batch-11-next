'use client'
import { redirect, useRouter } from "next/navigation";
import { useEffect, useState } from "react";

type Product = {
  id: number,
  productName: string
}
export default function Product() {
  const [ text, setText ] = useState<string>("")
  const [proudcts , setProudcts ] = useState<Product[]>([])

  const fetchProducts = async () => {
    const res = await fetch("http://localhost:3001/products")
    const data = await res.json()
    
    setProudcts(data)
  }

  const createProudcts = async () => {
    await fetch("http://localhost:3001/products", {
      method: "POST",
      body: JSON.stringify({ name: text})
    })
    router.refresh()
  }

  useEffect(() => {
    setTimeout(() => {
        fetchProducts()
    }, 5000);
      
  }, [])
  
  const router = useRouter()
  const handleClick = () => {
    console.log("test")
  }
  return (
    <div >
      Products
      <button onClick={handleClick}>go to test</button>
      <button onClick={createProudcts}>Create Product</button>
      <input type="text" value={text} onChange={(e) => setText(e.target.value)} />
      {
        proudcts.map((p, i) => <div key={i}>{p.productName}</div>)
      }
    </div>
  );
}
